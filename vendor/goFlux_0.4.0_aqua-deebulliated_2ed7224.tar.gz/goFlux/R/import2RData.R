#' Looping function for quick import of multiple raw gas measurement files
#'
#' Imports all raw gas measurement files contained in a folder.
#' Adapted to multiple greenhouse gas analyzers and other instruments:
#' * \strong{LI-COR}: LI-6400, LI-7810, LI-7820, LI-8100, LI-8150 (Multiplexer),
#'                    LI-8200 (smart chamber), LI-8250 (Multiplexer)
#' * \strong{Los Gatos Research (LGR)}: ultra-portable GGA (GLA132 series),
#'                                      micro ultra-portable GGA (GLA131 series),
#'                                      N2OM1 (GLA151 series), and the
#'                                      \ifelse{html}{\out{N<sub>2</sub>O}}{\eqn{N[2]O}{ASCII}}
#'                                      isotopic analyzer N2Oi2 (GLA451 series)
#' * \strong{GAIA2TECH (DMR)}: automated chamber ECOFlux
#' * \strong{Picarro}: G2201-i, G2508 and G4301
#' * \strong{Gasmet}: DX4015 and GT5000
#' * \strong{PP-Systems}: EGM-5
#' * \strong{Aeris Technologies}: \ifelse{html}{\out{N<sub>2</sub>O}}{\eqn{N[2]O}{ASCII}}/
#'                                \ifelse{html}{\out{CO<sub>2</sub>}}{\eqn{CO[2]}{ASCII}}
#'                                high accuracy analyzer and
#'                                \ifelse{html}{\out{CH<sub>4</sub>}}{\eqn{CH[4]}{ASCII}}/
#'                                \ifelse{html}{\out{C<sub>2</sub>H<sub>6</sub>}}{\eqn{C[2]H[6]}{ASCII}}
#'                                natural gas detection system
#' * \strong{EarthBound Scientific}: SkyLine2D system
#' * \strong{Healthy Photon}: HT8850
#' * \strong{Eosense}: eosMX 12-Channel Multiplexer
#' * \strong{GasmetPD}: Custom multiplexer from the University of Padova, Italy
#' @md
#'
#' @param path character string; a folder path containing all files to be imported.
#'             Ideally, to avoid any errors, the folder should only contain the
#'             files to be imported.
#' @param instrument character string; specifies which instrument was used to
#'                   generate the files contained in the folder path. Choose one
#'                   of the following: "DX4015", "eosMX12", "EGM5", "G2201i",
#'                   "G2508", "G4301", "GAIA", "GasmetPD", "GT5000", "HT8850",
#'                   "LI-6400", "LI-7810", "LI-7820", "LI-8100", "LI-8150",
#'                   "LI-8200", "LI-8250", "N2OM1", "N2Oi2", "skyline", "uCH4",
#'                   "uN2O", "UGGA". For more information about an instrument,
#'                   see the section "See Also" below.
#' @param date.format character string; specifies the date format found in the
#'                    raw data file. Choose one of the following: "dmy", "ymd",
#'                    or "mdy".
#' @param timezone character string; a time zone in which to import the data to
#'                 POSIXct format. Default is "UTC". Note about time zone: it is
#'                 recommended to use the time zone "UTC" to avoid any issue
#'                 related to summer time and winter time changes.
#' @param keep_all logical; if \code{keep_all = TRUE}, keep all columns from the raw
#'                 file. The default is \code{keep_all = FALSE}, and columns that
#'                 are not necessary for gas flux calculation are removed.
#' @param prec,prec1,prec2,prec3 numerical vector; the precision of the instrument
#'        for each gas. Look at the examples below, or the help for each import
#'        function of each instrument, to know what values to use.
#' @param merge logical; if TRUE, merge all files as one data frame and return
#'              it in the Console, or load it in the Environment if assigned to
#'              an object.
#' @param proc.data.field numeric value; select the process data field used with
#'                        the EGM-5. See \code{\link[goFlux]{import.EGM5}} for
#'                        more details.
#' @param pivot character string; either "long" or "wide". If \code{pivot = "long"},
#'              each column containing information about \code{Tsoil},
#'              \code{Tcham}, \code{SWC}, \code{PAR} and operating status
#'              (\code{Op.stat}) will be saved in a single column per parameter.
#'              If \code{pivot = "wide"}, the default display of one column per
#'              chamber per parameter will be used.
#'              Used with \code{instrument = "GAIA"} only.
#' @param active logical; if \code{active = TRUE}, preserve data for active
#'               chambers only. Used with \code{instrument = "GAIA"} only.
#' @param flag numeric vector; indicates the operating status that should be used
#'             for the flux calculation. Default is \code{flag = c(7,11)}, where
#'             7 indicates "Chamber Idle Closed Clear" and 11 indicates "Chamber
#'             Idle Closed Dark". Used with \code{instrument = "GAIA"} only.
#' @param background logical; if \code{background = FALSE}, removes all data from
#'                   opened chambers. Used with \code{instrument = "GAIA"} only.
#' @param deadband numerical; define a deadband at the start of measurements
#'                 (seconds). Used with \code{instrument = "skyline"} only.
#' @param shoulder numerical; include background data points before and after the
#'                 measurement (seconds). Used with \code{instrument = "skyline"} only.
#' @param CH.clo.col,Op.stat.col,PAR.col,Tcham.col,Tsoil.col,SWC.col,WTD.col,CH.col
#'        character vector; a pattern to match the columns that fit the corresponding
#'        parameter. See \code{\link[goFlux]{import.GAIA}}, \code{\link[goFlux]{import.LI8250}},
#'        or \code{\link[goFlux]{import.skyline}} for more details.
#' @param inst,inst1,inst2,inst3 character strings; a pattern to match the columns
#'        containing the name of each instrument. See
#'        \code{\link[goFlux]{import.GAIA}}, \code{\link[goFlux]{import.LI8250}}
#'        or \code{\link[goFlux]{import.skyline}} for more details.
#' @param gas,gas1,gas2,gas3 character vectors; a pattern to match the columns
#'        containing each gas measurement. See \code{\link[goFlux]{import.GAIA}},
#'        \code{\link[goFlux]{import.LI8250}}, \code{\link[goFlux]{import.GasmetPD}}
#'        or \code{\link[goFlux]{import.skyline}} for more details.
#' @param dry,dry1,dry2,dry3 logical; are the gas measurements compensated for water
#'        vapor (dry fraction)? If \code{dryX = TRUE} (default), the gases are
#'        compensated for water vapor, and will be named accordingly. See
#'        \code{\link[goFlux]{import.GAIA}}, \code{\link[goFlux]{import.LI8250}}
#'        or \code{\link[goFlux]{import.skyline}} for more details.
#' @param sensor1,sensor2 character strings; a pattern to match the columns
#'        containing the name of each sensor. By default,
#'        \code{sensor1 = "Analog Sensor1"}, \code{sensor2 = "Analog Sensor2"},
#'        to match the example data file provided with the package. Set to NULL
#'        to ignore these columns. Used with \code{instrument = "skyline"} only.
#' @param manual logical; indicates if measurements were made manually and there
#'               are no records of chamber identification, sequence, etc. If
#'               \code{TRUE}, the arguments \code{Op.stat.col}, \code{CH.col},
#'               \code{active}, \code{background}, \code{flag}, and \code{pivot}
#'               are ignored. Used with \code{instrument = "GAIA"} only.
#' @param sep character string defining the field separator character. Values on
#'            each line of the file are separated by this character. By default,
#'            \code{sep = "\t"} for tabulation. Used with
#'            \code{instrument = "GAIA"} only.
#' @param skip integer; the number of lines of the data file to skip before
#'             beginning to read data. By default, \code{skip = 1}. Used with
#'             \code{instrument = "GAIA"} only.
#' @param CH4 character string; which column should be used for
#'            \ifelse{html}{\out{CH<sub>4</sub>}}{\eqn{CH[4]}{ASCII}} concentration.
#'            By default, \code{CH4 = "HP_12CH4_dry"}. Used with
#'             \code{instrument = "G2201i"} only.
#' @param CO2 character string; which column should be used for
#'            \ifelse{html}{\out{CO<sub>2</sub>}}{\eqn{CO[2]}{ASCII}} concentration.
#'            By default, \code{CO2 = "12CO2_dry"}.Used with
#'             \code{instrument = "G2201i"} only.
#' @param sum logical; if \code{sum = TRUE} (default), the arguments \code{CH4} and
#'            \code{CO2} are ignored and, instead, both fractions (carbon isotope
#'            12 and 13) of each gas, are summed after correction for water vapor,
#'            to obtain the total gas concentration. See the argument \code{range}
#'            for the selection between the HP or the HR measurement of
#'            \ifelse{html}{\out{CH<sub>4</sub>}}{\eqn{CH[4]}{ASCII}} concentration.
#'            Used with \code{instrument = "G2201i"} only.
#' @param range numerical value; at which threshold should the function select
#'              between high precision (HP) and high resolution (HR) of
#'              \ifelse{html}{\out{CH<sub>4</sub>}}{\eqn{CH[4]}{ASCII}}
#'              concentration? The default is \code{range = 10}. If the methane
#'              concentration recorded in the column \code{HP_12CH4_dry} is above
#'              10 ppm, the concentration from the columns \code{HR_12CH4_dry}
#'              and \code{HR_13CH4} are used for the sum instead of HP.
#'              Used with \code{instrument = "G2201i"} only.
#'
#' @returns Raw files saved as RData in a newly created folder, RData, into
#'          the working directory.
#'
#' @details
#' In \code{date.format}, the date format refers to a date found in the raw data
#' file, not the date format in the file name. For most instruments, the date is
#' one of the columns in the raw data file:
#' \itemize{
#' \item DX4015: column Date
#' \item EGM5: column Date
#' \item G2201i: column DATE
#' \item G2508: column DATE
#' \item G4301: column DATE
#' \item GAIA: column Titles:
#' \item GasmetPD: column Date
#' \item GT5000: column Date
#' \item HT8850: column time
#' \item LI-6400: (see comment below)
#' \item LI-7810: column DATE
#' \item LI-7820: column DATE
#' \item LI-8100: column Date
#' \item LI-8150: column Date
#' \item LI-8200: (see comment below)
#' \item N2OM1: column Time
#' \item N2Oi2: column Time
#' \item SkyLine: column Titles:
#' \item uCH4: column Time Stamp
#' \item uN2O: column Time Stamp
#' \item UGGA: column Time
#' }
#' For the instrument LI-6400, the date is found in one of the first lines in
#' a format containing abbreviations, for example "Thr Aug 6 2020", which would
#' be the date format "mdy". For the instrument LI-8200, the date is found under
#' one of the measurements, next to '"Date":'. For the instrument LI-8250, the
#' date format is in the file name.
#'
#' The argument \code{proc.data.field} is used with the PP-Sytems EGM-5
#' instrument only. Look up the
#' \href{https://ppsystems.com/download/technical_manuals/80109-1-EGM-5_Operation_V103.pdf}{EGM-5 Operation Manual}
#' at page 90 for more details about the different Process Data Fields
#' (\code{proc.data.field}).
#'
#' The arguments \code{active}, \code{pivot}, \code{flag}, \code{PAR.col},
#' \code{Tcham.col}, \code{WTD.col}, \code{Op.stat.col}, \code{inst3},
#' \code{gas3}, \code{prec3}, \code{dry3}, \code{sep}, \code{manual} and
#' \code{skip} are used with the function \code{\link[goFlux]{import.GAIA}} only.
#' The arguments \code{Tsoil.col}, \code{SWC.col}, \code{inst1}, \code{inst2},
#' \code{gas1}, \code{gas2}, \code{prec1}, \code{prec2}, \code{dry1}, \code{dry2},
#' are used with both the function \code{\link[goFlux]{import.GAIA}} and the
#' function \code{\link[goFlux]{import.LI8250}}. The arguments \code{CH.col} and
#' \code{background} are used with the function \code{\link[goFlux]{import.GAIA}}.
#'
#' The arguments \code{CH4}, \code{CO2}, \code{sum} and \code{range} are used
#' with the function \code{\link[goFlux]{import.G2201i}} only.
#'
#' The arguments \code{CH.clo.col}, \code{sensor1}, \code{sensor2}, \code{inst}
#' and \code{dry} are used with the function \code{\link[goFlux]{import.skyline}} only.
#'
#' The argument \code{gas} is used with the functions
#' \code{\link[goFlux]{import.GasmetPD}} and \code{\link[goFlux]{import.skyline}}.
#'
#' @include goFlux-package.R
#' @include import.DX4015.R
#' @include import.eosMX12.R
#' @include import.EGM5.R
#' @include import.G2201i.R
#' @include import.G2508.R
#' @include import.G4301.R
#' @include import.GAIA.R
#' @include import.GasmetPD.R
#' @include import.GT5000.R
#' @include import.HT8850.R
#' @include import.LI6400.R
#' @include import.LI7810.R
#' @include import.LI7820.R
#' @include import.LI8100.R
#' @include import.LI8150.R
#' @include import.LI8200.R
#' @include import.LI8250.R
#' @include import.N2OM1.R
#' @include import.N2Oi2.R
#' @include import.skyline.R
#' @include import.uCH4.R
#' @include import.uN2O.R
#' @include import.UGGA.R
#'
#' @seealso Use the wrapper function \code{\link[goFlux]{import2RData}}
#'          to import multiple files from the same folder path using any instrument.
#' @seealso Import functions for individual instruments:
#'          \code{\link[goFlux]{import.DX4015}},
#'          \code{\link[goFlux]{import.eosMX12}},
#'          \code{\link[goFlux]{import.EGM5}},
#'          \code{\link[goFlux]{import.G2201i}},
#'          \code{\link[goFlux]{import.G2508}},
#'          \code{\link[goFlux]{import.G4301}},
#'          \code{\link[goFlux]{import.GAIA}},
#'          \code{\link[goFlux]{import.GasmetPD}},
#'          \code{\link[goFlux]{import.GT5000}},
#'          \code{\link[goFlux]{import.HT8850}},
#'          \code{\link[goFlux]{import.LI6400}},
#'          \code{\link[goFlux]{import.LI7810}},
#'          \code{\link[goFlux]{import.LI7820}},
#'          \code{\link[goFlux]{import.LI8100}},
#'          \code{\link[goFlux]{import.LI8150}},
#'          \code{\link[goFlux]{import.LI8200}},
#'          \code{\link[goFlux]{import.LI8250}},
#'          \code{\link[goFlux]{import.N2OM1}},
#'          \code{\link[goFlux]{import.N2Oi2}},
#'          \code{\link[goFlux]{import.skyline}},
#'          \code{\link[goFlux]{import.uCH4}},
#'          \code{\link[goFlux]{import.uN2O}},
#'          \code{\link[goFlux]{import.UGGA}}
#'
#' @examples
#'
#' # Examples on how to use it with all instruments.
#' # The default time zone "UTC" is used in all cases.
#'
#' # with the Gasmet instrument DX4015
#' file.path <- system.file("extdata/DX4015", package = "goFlux")
#' import2RData(path = file.path, instrument = "DX4015",
#'              date.format = "ymd", prec = c(1.6, 23, 13, 2, 23, 33))
#'
#' # with the Gasmet instrument GT5000
#' file.path <- system.file("extdata/GT5000", package = "goFlux")
#' import2RData(path = file.path, instrument = "GT5000",
#'              date.format = "ymd", prec = c(1.6, 23, 13, 2, 23, 33))
#'
#' # with the PP-Systems EGM-5
#' # The argument proc.data.field is used with the PP-System EGM-5 instrument only.
#' file.path <- system.file("extdata/EGM5", package = "goFlux")
#' import2RData(path = file.path, instrument = "EGM5",
#'              date.format = "dmy", prec = c(3, 1, 500), proc.data.field = 2)
#'
#' # with the Picarro instrument G2201i
#' file.path <- system.file("extdata/G2201i", package = "goFlux")
#' import2RData(path = file.path, instrument = "G2201i",
#'              date.format = "ymd", prec = c(0.2, 50, 100))
#'
#' # with the Picarro instrument G2508
#' file.path <- system.file("extdata/G2508", package = "goFlux")
#' import2RData(path = file.path, instrument = "G2508",
#'              date.format = "ymd", prec = c(0.24, 0.3, 5, 0.16, 500))
#'
#' # with the Picarro instrument G4301
#' file.path <- system.file("extdata/G4301", package = "goFlux")
#' import2RData(path = file.path, instrument = "G4301",
#'              date.format = "ymd", prec = c(0.025, 0.1, 10))
#'
#' # with the automated chamber ECOFlux (GAIA2TECH)
#' # with this instrument, "keep_all" is not a valid argument.
#' file.path <- system.file("extdata/GAIA", package = "goFlux")
#' import2RData(path = file.path, instrument = "GAIA", date.format = "ymd",
#'              pivot = "long", active = TRUE, flag = c(7,11),
#'              background = FALSE,
#'              CH.col = "COM5A0",
#'              SWC.col = "1C08_Soil Moisture",
#'              Tsoil.col = "1C07_Soil Temperature",
#'              Tcham.col = "2C07_Chamber Temperature",
#'              PAR.col = "3C07_Sunlight",
#'              WTD.col = NULL,
#'              Op.stat.col = "0C06_OperatingStatus",
#'              inst1 = "XT2C00_Instrument",
#'              inst2 = "XT3C00_Instrument",
#'              gas1 = c("XT2C04_CH4", "XT2C05_CO2", "XT2C06_H2O"),
#'              gas2 = c("XT3C04_N2O", "XT3C05_H2O"),
#'              prec1 = c(0.6, 3.5, 45),
#'              prec2 = c(0.4, 45))
#'
#' # with the custom multiplexer from the University of Padova (GasmetPD)
#' file.path <- system.file("extdata/GasmetPD", package = "goFlux")
#' import2RData(path = file.path, instrument = "GasmetPD",
#'              gas = c("CO2_ppm", "CH4_ppm", "N2O_ppm", "NH3_ppm", "H2O_pct"),
#'              date.format = "ymd", prec = c(1.6, 13, 2, 23, 33))
#'
#' # with Los Gatos Research UGGA (GLA132 series)
#' file.path <- system.file("extdata/UGGA", package = "goFlux")
#' import2RData(path = file.path, instrument = "UGGA",
#'              date.format = "dmy", prec = c(0.2, 1.4, 50))
#'
#' # with Los Gatos Research m-GGA (GLA131 series)
#' file.path <- system.file("extdata/UGGA", package = "goFlux")
#' import2RData(path = file.path, instrument = "UGGA",
#'              date.format = "dmy", prec = c(0.35, 0.9, 200))
#'
#' # with Los Gatos Research N2OM1 (GLA151 series)
#' file.path <- system.file("extdata/N2OM1", package = "goFlux")
#' import2RData(path = file.path, instrument = "N2OM1",
#'              date.format = "dmy", prec = c(0.5, 2, 50))
#'
#' # with Los Gatos Research N2Oi2 (GLA451 series)
#' file.path <- system.file("extdata/N2Oi2", package = "goFlux")
#' import2RData(path = file.path, instrument = "N2Oi2",
#'              date.format = "dmy", prec = c(0.05, 50))
#'
#' # with the LI-COR LI-6400 gas analyzer
#' file.path <- system.file("extdata/LI6400", package = "goFlux")
#' import2RData(path = file.path, instrument = "LI-6400",
#'              date.format = "mdy", prec = c(0.15, 20))
#'
#' # with the LI-COR LI-7810 gas analyzer
#' file.path <- system.file("extdata/LI7810", package = "goFlux")
#' import2RData(path = file.path, instrument = "LI-7810",
#'              date.format = "ymd", prec = c(3.5, 0.6, 45))
#'
#' # with the LI-COR LI-7820 gas analyzer
#' file.path <- system.file("extdata/LI7820", package = "goFlux")
#' import2RData(path = file.path, instrument = "LI-7820",
#'              date.format = "ymd", prec = c(0.4, 45))
#'
#' # with the LI-COR LI-8100 gas analyzer
#' file.path <- system.file("extdata/LI8100", package = "goFlux")
#' import2RData(path = file.path, instrument = "LI-8100",
#'              date.format = "ymd", prec = c(1, 10))
#'
#' # with the LI-COR LI-8150 Multiplexer and LI-8100A gas analyzer
#' file.path <- system.file("extdata/LI8150", package = "goFlux")
#' import2RData(path = file.path, instrument = "LI-8150",
#'              date.format = "ymd", prec = c(1, 10))
#'
#' # with the LI-COR smart chamber (LI-8200)
#' # with this instrument, "keep_all" and "prec" are not valid arguments.
#' file.path <- system.file("extdata/LI8200", package = "goFlux")
#' import2RData(path = file.path, instrument = "LI-8200", date.format = "ymd")
#'
#' # with the LI-COR Multiplexer (LI-8250)
#' file.path <- system.file("extdata/LI8250", package = "goFlux")
#' import2RData(path = file.path, instrument = "LI-8250", date.format = "ymd",
#'              inst1 = "LI-7810", gas1 = c("CO2_DRY", "CH4_DRY", "H2O"),
#'              prec1 = c(3.5, 0.6, 45), SWC.col = "SWC_1", Tsoil.col = "TS_1")
#'
#' # with the SkyLine2D system (EarthBound Scientific)
#' # with this instrument, "keep_all" is not a valid argument.
#' file.path <- system.file("extdata/skyline", package = "goFlux")
#' import2RData(path = file.path, instrument = "skyline", date.format = "ymd",
#'              deadband = 0,
#'              shoulder = 20,
#'              CH.col = "CH ID",
#'              CH.clo.col = "Chamber closed",
#'              sensor1 = "Analog Sensor1",
#'              sensor2 = "Analog Sensor2",
#'              inst = "Instrument",
#'              gas = c("CO2", "CH4 Dry", "N2O Dry", "H2O"),
#'              prec = c(0.24, 0.3, 5, 500))
#'
#' # with the Aeris Technologies MIRA Ultra CH4/C2H6 analyzer
#' file.path <- system.file("extdata/uCH4", package = "goFlux")
#' import2RData(path = file.path, instrument = "uCH4",
#'              date.format = "mdy", prec = c(1, 0.5, 15))
#'
#' # with the Aeris Technologies MIRA Ultra N2O/CO2 analyzer
#' file.path <- system.file("extdata/uN2O", package = "goFlux")
#' import2RData(path = file.path, instrument = "uN2O",
#'              date.format = "mdy", prec = c(0.2, 0.2, 15))
#'
#' # with the Healthy Photon HT8850 all-in-one GHG analyzer
#' file.path <- system.file("extdata/HT8850", package = "goFlux")
#' import2RData(path = file.path, instrument = "HT8850",
#'              date.format = "ymd", prec = c(0.5, 3, 0.5, 10))
#'
#' # with the Eosense eosMX 12-Channel Multiplexer
#' file.path <- system.file("extdata/eosMX12", package = "goFlux")
#' import2RData(path = file.path, instrument = "eosMX12")
#'
#' @export

import2RData <- function(path, instrument, date.format, timezone = "UTC",
                         keep_all = FALSE, prec, merge = FALSE,
                         proc.data.field = NULL, pivot = "long",
                         active = TRUE, flag = c(7,11), background = FALSE,
                         deadband = 0, shoulder = 20,
                         SWC.col, Tsoil.col, Tcham.col, PAR.col, WTD.col,
                         CH.col, Op.stat.col, CH.clo.col,
                         sensor1, sensor2,
                         inst1, inst2 = NULL, inst3 = NULL, inst,
                         gas1, gas2 = NULL, gas3 = NULL, gas,
                         prec1, prec2 = NULL, prec3 = NULL,
                         dry1 = T, dry2 = T, dry3 = NULL, dry = T,
                         manual = F, sep = "\t", skip = 1,
                         CH4 = "HP_12CH4_dry", CO2 = "12CO2_dry",
                         sum = TRUE, range = 10){

  # Check arguments ####
  if(missing(path)) stop("'path' is required")
  if(!is.null(path) & !is.character(path)) stop("'path' must be a character string")
  if(missing(instrument)) stop("'instrument' is required")
  if(length(instrument) != 1) stop("'instrument' must be of length 1")
  if(!any(grepl(paste("\\<", instrument, "\\>", sep = ""),
                c("DX4015", "UGGA", "G2201i", "G2508", "G4301", "GAIA", "LI-6400",
                  "EGM5", "LI-7810", "LI-7820", "LI-8100", "LI-8150", "LI-8200",
                  "N2OM1", "N2Oi2", "uCH4", "uN2O", "GasmetPD", "GT5000", "LI-8250",
                  "skyline", "HT8850", "eosMX12")))){
    stop(paste("'instrument' must be of class character and one of the following:",
               "'DX4015', 'eosMX12' 'EGM5', 'G2201i', 'G2508', 'G4301', 'GAIA',",
               "'GasmetPD', 'GT5000', 'HT8850', 'LI-6400', 'LI-7810', 'LI-7820',",
               "'LI-8100', 'LI-8150', 'LI-8200', 'LI-8250', 'UGGA', 'N2OM1',",
               "'N2Oi2', 'skyline', 'uCH4', 'uN2O'"))}
  if(!missing(date.format)){
    if(length(date.format) != 1) stop("'date.format' must be of length 1")
    if (!is.character(date.format)) stop("'date.format' must be of class character")
    if (!any(grepl(date.format, c("ymd", "dmy", "mdy")))) {
      stop("'date.format' must be one of the following: 'ymd', 'dmy' or 'mdy'")}}
  if(!is.character(timezone)) stop("'timezone' must be of class character")
  if(merge != TRUE & merge != FALSE) stop("'merge' must be TRUE or FALSE")

  # FUNCTION STARTS ####

  # Progress bar options
  pboptions(char = "=")

  # Catch errors and messages from import function to print after progress bar
  errs <- character(0)
  msgs <- character(0)
  warn <- character(0)

  # DX4015 ####
  if(instrument == "DX4015"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = "\\.TXT", recursive = T,
                            full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .TXT was",
                                       "found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.DX4015(inputfile = file_list[i],
                      date.format = date.format,
                      timezone = timezone,
                      save = TRUE,
                      keep_all = keep_all,
                      prec = prec),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # eosMX12 ####
  if(instrument == "eosMX12"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = ".log",
                            recursive = T, full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .log",
                                       "was found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.eosMX12(inputfile = file_list[i],
                       timezone = timezone,
                       save = TRUE),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # EGM5 ####
  if(instrument == "EGM5"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = "\\.TXT|\\.csv",
                            recursive = T, full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .TXT or .csv",
                                       "was found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.EGM5(inputfile = file_list[i],
                    date.format = date.format,
                    timezone = timezone,
                    save = TRUE,
                    keep_all = keep_all,
                    prec = prec,
                    proc.data.field = proc.data.field),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # G2201i ####
  if(instrument == "G2201i"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = "\\.dat", recursive = T,
                            full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .dat",
                                       "was found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.G2201i(inputfile = file_list[i],
                      date.format = date.format,
                      timezone = timezone,
                      save = TRUE,
                      keep_all = keep_all,
                      prec = prec,
                      CH4 = CH4,
                      CO2 = CO2,
                      sum = sum,
                      range = range),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # G2508 ####
  if(instrument == "G2508"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = "\\.dat", recursive = T,
                            full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .dat",
                                       "was found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.G2508(inputfile = file_list[i],
                     date.format = date.format,
                     timezone = timezone,
                     save = TRUE,
                     keep_all = keep_all,
                     prec = prec),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # G4301 ####
  if(instrument == "G4301"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = "\\.dat", recursive = T,
                            full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .dat",
                                       "was found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.G4301(inputfile = file_list[i],
                     date.format = date.format,
                     timezone = timezone,
                     save = TRUE,
                     keep_all = keep_all,
                     prec = prec),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # GAIA ####
  if(instrument == "GAIA"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = "\\.csv", full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .csv",
                                       "was found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.GAIA(inputfile = file_list[i], date.format = date.format,
                    timezone = timezone, pivot = pivot,
                    active = active, flag = flag,
                    background = background, save = TRUE,
                    CH.col = CH.col, SWC.col = SWC.col, WTD.col = WTD.col,
                    Tsoil.col = Tsoil.col, Tcham.col = Tcham.col,
                    PAR.col = PAR.col, Op.stat.col = Op.stat.col,
                    inst1 = inst1, inst2 = inst2, inst3 = inst3,
                    gas1 = gas1, gas2 = gas2, gas3 = gas3,
                    prec1 = prec1, prec2 = prec2, prec3 = prec3,
                    dry1 = dry1, dry2 = dry2, dry3 = dry3,
                    manual = manual, sep = sep, skip = skip),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # Custom: GasmetPD ####
  if(instrument == "GasmetPD"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = "\\.txt", full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .txt",
                                       "was found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.GasmetPD(inputfile = file_list[i],
                        date.format = date.format,
                        timezone = timezone,
                        save = TRUE,
                        keep_all = keep_all,
                        gas = gas,
                        prec = prec),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # GT5000 ####
  if(instrument == "GT5000"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = "\\.TXT", recursive = T,
                            full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .TXT",
                                       "was found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.GT5000(inputfile = file_list[i],
                      date.format = date.format,
                      timezone = timezone,
                      save = TRUE,
                      keep_all = keep_all,
                      prec = prec),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # Los Gatos Research ####
  if(instrument == "UGGA"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = "\\.txt", full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .txt or .csv",
                                       "was found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.UGGA(inputfile = file_list[i],
                    date.format = date.format,
                    timezone = timezone,
                    save = TRUE,
                    keep_all = keep_all,
                    prec = prec),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # HT8850 ####
  if(instrument == "HT8850"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = "\\.txt", full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .txt",
                                       "was found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.HT8850(inputfile = file_list[i],
                      date.format = date.format,
                      timezone = timezone,
                      save = TRUE,
                      prec = prec),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # LI-6400 ####
  if(instrument == "LI-6400"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = "\\.txt", full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .txt",
                                       "was found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.LI6400(inputfile = file_list[i],
                      date.format = date.format,
                      timezone = timezone,
                      save = TRUE,
                      keep_all = keep_all,
                      prec = prec),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # LI-7810 ####
  if(instrument == "LI-7810"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = "\\.data|\\.txt", full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .data or .txt",
                                       "was found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.LI7810(inputfile = file_list[i],
                      date.format = date.format,
                      timezone = timezone,
                      save = TRUE,
                      keep_all = keep_all,
                      prec = prec),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # LI-7820 ####
  if(instrument == "LI-7820"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = "\\.data|\\.txt", full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .data or .txt",
                                       "was found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.LI7820(inputfile = file_list[i],
                      date.format = date.format,
                      timezone = timezone,
                      save = TRUE,
                      keep_all = keep_all,
                      prec = prec),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # LI-8100 ####
  if(instrument == "LI-8100"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = "\\.81x", full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .81x",
                                       "was found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.LI8100(inputfile = file_list[i],
                      date.format = date.format,
                      timezone = timezone,
                      save = TRUE,
                      keep_all = keep_all,
                      prec = prec),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # LI-8150 Multiplexer ####
  if(instrument == "LI-8150"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = "\\.81x", full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .81x",
                                       "was found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.LI8150(inputfile = file_list[i],
                      date.format = date.format,
                      timezone = timezone,
                      save = TRUE,
                      keep_all = keep_all,
                      prec = prec),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # LI-8200 Smart Chamber ####
  if(instrument == "LI-8200"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = "\\.json", full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .json",
                                       "was found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.LI8200(inputfile = file_list[i],
                      date.format = date.format,
                      timezone = timezone,
                      save = TRUE),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # LI-8250 Multiplexer ####
  if(instrument == "LI-8250"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = "\\.82z", full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .82z",
                                       "was found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.LI8250(inputfile = file_list[i], date.format = date.format,
                      timezone = timezone, save = TRUE, keep_all = keep_all,
                      inst1 = inst1, inst2 = inst2, gas1 = gas1, gas2 = gas2,
                      prec1 = prec1, prec2 = prec2, dry1 = dry1, dry2 = dry2,
                      SWC.col = SWC.col, Tsoil.col = Tsoil.col),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # N2OM1 ####
  if(instrument == "N2OM1"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = "\\.txt", full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .txt",
                                       "was found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.N2OM1(inputfile = file_list[i],
                     date.format = date.format,
                     timezone = timezone,
                     save = TRUE,
                     keep_all = keep_all,
                     prec = prec),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # N2Oi2 ####
  if(instrument == "N2Oi2"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = "\\.txt", full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .txt",
                                       "was found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.N2Oi2(inputfile = file_list[i],
                     date.format = date.format,
                     timezone = timezone,
                     save = TRUE,
                     keep_all = keep_all,
                     prec = prec),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # skyline ####
  if(instrument == "skyline"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = "\\.csv", full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .csv",
                                       "was found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.skyline(inputfile = file_list[i], date.format = date.format,
                       timezone = timezone, deadband = deadband,
                       shoulder = shoulder, save = TRUE,
                       CH.col = CH.col, CH.clo.col = CH.clo.col,
                       sensor1 = sensor1, sensor2 = sensor2,
                       inst = inst, gas = gas, prec = prec, dry = dry),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # uCH4 ####
  if(instrument == "uCH4"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = "\\.txt", full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .txt",
                                       "was found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.uCH4(inputfile = file_list[i],
                    date.format = date.format,
                    timezone = timezone,
                    save = TRUE,
                    keep_all = keep_all,
                    prec = prec),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # uN2O ####
  if(instrument == "uN2O"){

    # List all the files contained in the specified path
    file_list <- list.files(path = path, pattern = "\\.txt", full.names = TRUE)

    # Error if file_list is empty
    if(is_empty(file_list)) stop(paste("No file with the extension .txt",
                                       "was found in the folder path", path))

    # Loop through files in "file_list" and apply import functions
    pblapply(seq_along(file_list), function(i) {

      withCallingHandlers(

        import.uN2O(inputfile = file_list[i],
                     date.format = date.format,
                     timezone = timezone,
                     save = TRUE,
                     keep_all = keep_all,
                     prec = prec),

        error = function(e){
          errs <<- c(errs, conditionMessage(e))
          invokeRestart("muffleError")
        },
        warning = function(w){
          warn <<- c(warn, conditionMessage(w))
          invokeRestart("muffleWarning")
        },
        message = function(m){
          msgs <<- c(msgs, conditionMessage(m))
          invokeRestart("muffleMessage")
        })
    })
  }

  # Merge and load
  if(merge == TRUE){
    all.imp <- list.files(path = "RData", pattern = "imp.RData", full.names = TRUE) %>%
      map_df(~ get(load(.x)))

    return(all.imp)
  }

  # Print errors and messages after progress bar
  msgs <- trimws(msgs); for (m in msgs) message(m)
  errs <- trimws(errs); for (e in errs) warning(e, call. = F)
  warn <- trimws(warn); for (w in warn) warning(w, call. = F)
}
